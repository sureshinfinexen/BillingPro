BillingPro sample pack
======================
Order of use:
1) 01_products_sample.csv  → Products → Upload
2) 02_suppliers_sample.csv → Samples / Suppliers upload
3) 03_grn_stock_in_sample.csv → Purchases → Bulk GRN
4) 04_supplier_template_products.csv → Supplier template edit → Upload
5) 05_coupons / 06_customers as needed
Or click Load demo pack on the Samples page to insert everything at once.
